"use client"

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { useSession } from "@/lib/auth-client";

const roleRoutes: Record<string, string> = {
  student: "/dashboard/student",
  employer: "/dashboard/employer",
  mentor: "/dashboard/mentor",
  placement: "/dashboard/placement",
};

export function RoleGuard({ allowed }: { allowed: keyof typeof roleRoutes }) {
  const router = useRouter();
  const { data: session, isPending } = useSession();

  useEffect(() => {
    if (isPending) return;

    // If not logged in, send to sign-in
    if (!session?.user) {
      router.replace("/sign-in");
      return;
    }

    // Basic role from localStorage (since no role field in DB yet)
    const storedRole = (typeof window !== "undefined" && localStorage.getItem("role")) || undefined;

    if (!storedRole) {
      // Default to student if not set
      localStorage.setItem("role", "student");
      if (allowed !== "student") router.replace(roleRoutes["student"]);
      return;
    }

    if (storedRole !== allowed) {
      // Redirect to appropriate dashboard
      const target = roleRoutes[storedRole] ?? "/";
      if (target) router.replace(target);
    }
  }, [session, isPending, allowed, router]);

  return null;
}

export default RoleGuard;
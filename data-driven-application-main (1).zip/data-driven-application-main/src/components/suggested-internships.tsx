import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Briefcase, MapPin, Clock, TrendingUp } from "lucide-react";
import Link from "next/link";

interface InternshipProps {
  title: string;
  company: string;
  location: string;
  duration: string;
  type: string;
  description: string;
}

const internships: InternshipProps[] = [
  {
    title: "Software Development Intern",
    company: "Tech Solutions Inc",
    location: "Bangalore",
    duration: "3 months",
    type: "Full-time",
    description: "Work on web applications using React and Node.js"
  },
  {
    title: "Data Science Intern",
    company: "Analytics Pro",
    location: "Mumbai",
    duration: "6 months",
    type: "Full-time",
    description: "Analyze datasets and build ML models"
  },
  {
    title: "Marketing Intern",
    company: "Brand Builders",
    location: "Delhi",
    duration: "3 months",
    type: "Part-time",
    description: "Social media campaigns and content creation"
  },
  {
    title: "UI/UX Design Intern",
    company: "Creative Studios",
    location: "Hyderabad",
    duration: "4 months",
    type: "Full-time",
    description: "Design user interfaces for mobile and web apps"
  },
  {
    title: "Business Analyst Intern",
    company: "Consulting Group",
    location: "Pune",
    duration: "6 months",
    type: "Full-time",
    description: "Market research and business strategy development"
  },
  {
    title: "Content Writing Intern",
    company: "Media House",
    location: "Chennai",
    duration: "3 months",
    type: "Remote",
    description: "Write blogs, articles, and technical documentation"
  }
];

export function SuggestedInternships({ roleType }: { roleType?: "student" | "employer" | "mentor" | "placement" }) {
  const getHeading = () => {
    switch (roleType) {
      case "student":
        return "Suggested Internships for You";
      case "employer":
        return "Popular Internship Categories";
      case "mentor":
        return "Internships Seeking Mentors";
      case "placement":
        return "Active Internship Programs";
      default:
        return "Featured Internship Programs";
    }
  };

  const getDescription = () => {
    switch (roleType) {
      case "student":
        return "Based on your profile and interests";
      case "employer":
        return "High-demand roles across industries";
      case "mentor":
        return "Opportunities where your guidance is needed";
      case "placement":
        return "Current opportunities for campus students";
      default:
        return "Explore trending opportunities";
    }
  };

  return (
    <section className="mt-10">
      <div className="mb-6">
        <h2 className="text-xl font-semibold flex items-center gap-2">
          <TrendingUp className="h-5 w-5 text-primary" />
          {getHeading()}
        </h2>
        <p className="text-sm text-muted-foreground mt-1">{getDescription()}</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {internships.map((internship, idx) => (
          <Card key={idx} className="group hover:shadow-lg transition-all">
            <CardHeader>
              <div className="flex items-start justify-between gap-2">
                <div className="flex-1">
                  <CardTitle className="text-base group-hover:text-primary transition-colors">
                    {internship.title}
                  </CardTitle>
                  <CardDescription className="mt-1">{internship.company}</CardDescription>
                </div>
                <Briefcase className="h-5 w-5 text-muted-foreground" />
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              <p className="text-sm text-muted-foreground">{internship.description}</p>
              
              <div className="flex flex-wrap gap-2 text-xs text-muted-foreground">
                <span className="flex items-center gap-1">
                  <MapPin className="h-3 w-3" />
                  {internship.location}
                </span>
                <span className="flex items-center gap-1">
                  <Clock className="h-3 w-3" />
                  {internship.duration}
                </span>
                <span className="rounded-full bg-primary/10 px-2 py-0.5 text-primary">
                  {internship.type}
                </span>
              </div>

              <Link href="/marketplace">
                <Button size="sm" variant="outline" className="w-full">
                  {roleType === "employer" ? "View Similar" : "View Details"}
                </Button>
              </Link>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="mt-6 text-center">
        <Link href="/marketplace">
          <Button variant="outline">View All Opportunities →</Button>
        </Link>
      </div>
    </section>
  );
}
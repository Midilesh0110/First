"use client"

import Link from "next/link";
import { useSession } from "@/lib/auth-client";
import { Button } from "@/components/ui/button";

export const SignInCTA = () => {
  const { data: session, isPending } = useSession();

  if (isPending) return null;
  if (session?.user) return null; // Hide when authenticated

  return (
    <Link href="/sign-in">
      <Button size="lg" variant="outline">Sign In</Button>
    </Link>
  );
};

export default SignInCTA;
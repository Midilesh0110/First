"use client"

import Link from "next/link";
import { useRouter } from "next/navigation";
import { authClient, useSession } from "@/lib/auth-client";

export const HeaderAuth = () => {
  const { data: session, isPending, refetch } = useSession();
  const router = useRouter();

  if (isPending) return null;

  if (session?.user) {
    const displayName = session.user.name || session.user.email || "User";

    const handleSignOut = async () => {
      const { error } = await authClient.signOut();
      if (!error?.code) {
        localStorage.removeItem("bearer_token");
        await refetch();
        router.push("/");
      }
    };

    return (
      <div className="flex items-center gap-3 text-sm">
        <span className="hidden sm:inline text-muted-foreground">Hi, {displayName}</span>
        <button onClick={handleSignOut} className="px-3 py-1.5 rounded-md border hover:bg-muted">Logout</button>
      </div>
    );
  }

  return (
    <div className="flex items-center gap-3 text-sm">
      <Link href="/sign-in" className="px-3 py-1.5 rounded-md border hover:bg-muted">Sign in</Link>
      <Link href="/sign-up" className="px-3 py-1.5 rounded-md bg-foreground text-background hover:opacity-90">Sign up</Link>
    </div>
  );
};

export default HeaderAuth;
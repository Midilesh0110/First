"use client"

import { useMemo, useState } from "react";
import Link from "next/link";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export interface AdvisorInput {
  educationLevel: string;
  degree: string;
  branch: string;
  cgpa: string;
  achievements: string;
  skills: string; // comma separated
}

interface Recommendation {
  title: string;
  reason: string;
}

interface RoadmapStep {
  title: string;
  items: string[];
}

const normalize = (s: string) => s.toLowerCase().trim();

const defaultInput: AdvisorInput = {
  educationLevel: "Undergraduate",
  degree: "B.Tech / B.E.",
  branch: "Computer Science",
  cgpa: "8.0",
  achievements: "",
  skills: "JavaScript, React, HTML, CSS",
};

function computeRecommendations(input: AdvisorInput): { options: Recommendation[]; roadmap: RoadmapStep[] } {
  const skills = input.skills
    .split(",")
    .map((s) => normalize(s))
    .filter(Boolean);
  const ach = normalize(input.achievements);
  const branch = normalize(input.branch);

  const options: Recommendation[] = [];

  const has = (k: string) => skills.some((s) => s.includes(k));

  if (has("react") || has("frontend") || has("javascript")) {
    options.push({
      title: "Frontend Web Development Internship",
      reason: "You listed React/JS/HTML/CSS skills suited for modern frontend roles.",
    });
  }
  if (has("java") || has("spring") || has("backend") || has("node")) {
    options.push({
      title: "Backend/API Development Internship",
      reason: "Java/Spring or Node skills align with server-side engineering.",
    });
  }
  if (has("python") || has("pandas") || has("sql") || has("data")) {
    options.push({
      title: "Data Analyst / Data Engineering Internship",
      reason: "Your Python/SQL/Data stack maps to analytics and pipelines.",
    });
  }
  if (has("ml") || has("machine learning") || has("tensorflow") || has("pytorch")) {
    options.push({
      title: "ML Engineer / Research Internship",
      reason: "You indicated ML-focused skills and tools.",
    });
  }
  if (has("ui") || has("ux") || has("figma") || has("design")) {
    options.push({
      title: "Product Design / UX Internship",
      reason: "Design and prototyping skills match UX roles.",
    });
  }

  if (options.length === 0) {
    options.push({
      title: "General Software Engineering Internship",
      reason: "Based on your profile, a broad SWE role is a solid starting point.",
    });
  }

  const roadmap: RoadmapStep[] = [];

  // Phase 1: Foundations
  roadmap.push({
    title: "Phase 1 • Foundations (2–4 weeks)",
    items: [
      "Solidify CS fundamentals: DSA basics, OOP, and Git workflows.",
      has("react") || branch.includes("computer")
        ? "Build a small responsive site with React + Tailwind."
        : "Pick a primary stack (e.g., React/Node or Java/Spring) and ship a mini project.",
      has("sql") ? "Revise SQL joins, indexing, and query optimization." : "Learn SQL basics via 5–8 practice problems.",
    ],
  });

  // Phase 2: Portfolio Project
  roadmap.push({
    title: "Phase 2 • Portfolio Project (3–6 weeks)",
    items: [
      has("react")
        ? "Ship a full-stack app: React frontend + simple API (Node/Spring) + database (Postgres)."
        : has("java")
        ? "Ship REST APIs with Spring Boot + JPA + Postgres; add Swagger and tests."
        : "Create a meaningful project in your chosen stack and write a clear README with screenshots.",
      "Add CI (GitHub Actions) and deploy (Vercel/Render/Fly.io).",
      ach.includes("hackathon") ? "Polish and publish your hackathon project as a case study." : "Write a 1–2 page case study for your project (problem, approach, results).",
    ],
  });

  // Phase 3: Internship Applications
  roadmap.push({
    title: "Phase 3 • Applications (2–4 weeks)",
    items: [
      "Shortlist 20–30 roles matched to your skills; tailor your resume with project impact.",
      "Practice role-specific interviews (frontend system design, API design, SQL/analytics as relevant).",
      "Network: reach out to alumni/mentors and request referrals with concise context.",
    ],
  });

  // Phase 4: Deepening Expertise
  roadmap.push({
    title: "Phase 4 • Deepening Expertise (ongoing)",
    items: [
      has("ml") || has("data") ? "Publish a data/ML notebook or blog each month." : "Write monthly posts about your projects and learnings.",
      has("java") ? "Contribute a small PR to an open-source Spring project." : "Contribute to an OSS library you use.",
    ],
  });

  return { options, roadmap };
}

export const PathAdvisor = () => {
  const [form, setForm] = useState<AdvisorInput>(defaultInput);
  const { options, roadmap } = useMemo(() => computeRecommendations(form), [form]);

  return (
    <Card>
      <CardHeader>
        <CardTitle>Career Advisor</CardTitle>
        <CardDescription>Enter your details — we’ll suggest roles and a personalized roadmap.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid gap-4 md:grid-cols-2">
          <div className="space-y-2">
            <label className="text-sm font-medium">Education level</label>
            <input
              className="w-full rounded-md border bg-background px-3 py-2 text-sm"
              value={form.educationLevel}
              onChange={(e) => setForm((f) => ({ ...f, educationLevel: e.target.value }))}
              placeholder="Undergraduate / Postgraduate / Diploma"
            />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium">Degree</label>
            <input
              className="w-full rounded-md border bg-background px-3 py-2 text-sm"
              value={form.degree}
              onChange={(e) => setForm((f) => ({ ...f, degree: e.target.value }))}
              placeholder="B.Tech / B.E. / B.Sc / M.Tech ..."
            />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium">Branch / Major</label>
            <input
              className="w-full rounded-md border bg-background px-3 py-2 text-sm"
              value={form.branch}
              onChange={(e) => setForm((f) => ({ ...f, branch: e.target.value }))}
              placeholder="Computer Science / IT / ECE ..."
            />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium">CGPA / Percentage</label>
            <input
              className="w-full rounded-md border bg-background px-3 py-2 text-sm"
              value={form.cgpa}
              onChange={(e) => setForm((f) => ({ ...f, cgpa: e.target.value }))}
              placeholder="e.g., 8.2"
            />
          </div>
          <div className="md:col-span-2 space-y-2">
            <label className="text-sm font-medium">Achievements</label>
            <textarea
              className="min-h-[72px] w-full rounded-md border bg-background px-3 py-2 text-sm"
              value={form.achievements}
              onChange={(e) => setForm((f) => ({ ...f, achievements: e.target.value }))}
              placeholder="Hackathons, research papers, competitions, leadership, etc."
            />
          </div>
          <div className="md:col-span-2 space-y-2">
            <label className="text-sm font-medium">Skills (comma-separated)</label>
            <input
              className="w-full rounded-md border bg-background px-3 py-2 text-sm"
              value={form.skills}
              onChange={(e) => setForm((f) => ({ ...f, skills: e.target.value }))}
              placeholder="e.g., JavaScript, React, SQL, Python"
            />
          </div>
        </div>

        <div className="flex flex-wrap gap-2 pt-2">
          {form.skills
            .split(",")
            .map((s) => s.trim())
            .filter(Boolean)
            .map((s) => (
              <span key={s} className="rounded-full bg-secondary px-3 py-1 text-xs text-secondary-foreground">
                {s}
              </span>
            ))}
        </div>

        <div className="space-y-3">
          <h3 className="text-base font-semibold">Recommended options</h3>
          <ul className="space-y-3">
            {options.map((opt) => (
              <li key={opt.title} className="rounded-md border p-3">
                <div className="font-medium">{opt.title}</div>
                <p className="text-sm text-muted-foreground">{opt.reason}</p>
              </li>
            ))}
          </ul>
          <div className="pt-1">
            <Link href="/marketplace">
              <Button>Explore matching internships</Button>
            </Link>
          </div>
        </div>

        <div className="space-y-3">
          <h3 className="text-base font-semibold">Personalized roadmap</h3>
          <div className="grid gap-3 md:grid-cols-2">
            {roadmap.map((step) => (
              <Card key={step.title}>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm">{step.title}</CardTitle>
                </CardHeader>
                <CardContent className="pt-0">
                  <ul className="list-disc space-y-1 pl-5 text-sm">
                    {step.items.map((it, idx) => (
                      <li key={idx}>{it}</li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default PathAdvisor;
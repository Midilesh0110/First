"use client";

import { useEffect, useRef } from "react";

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
}

interface Character {
  x: number;
  y: number;
  vx: number;
  vy: number;
  type: "student" | "employer" | "mentor" | "placement";
  rotation: number;
  rotationSpeed: number;
}

export function AnimatedBackground() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animationFrameId: number;
    let particles: Particle[] = [];
    let characters: Character[] = [];

    const resizeCanvas = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    const createParticles = () => {
      const particleCount = Math.floor((canvas.width * canvas.height) / 15000);
      particles = [];

      for (let i = 0; i < particleCount; i++) {
        particles.push({
          x: Math.random() * canvas.width,
          y: Math.random() * canvas.height,
          vx: (Math.random() - 0.5) * 0.3,
          vy: (Math.random() - 0.5) * 0.3,
        });
      }
    };

    const createCharacters = () => {
      const characterTypes: Character["type"][] = ["student", "employer", "mentor", "placement"];
      const characterCount = 8;
      characters = [];

      for (let i = 0; i < characterCount; i++) {
        characters.push({
          x: Math.random() * canvas.width,
          y: Math.random() * canvas.height,
          vx: (Math.random() - 0.5) * 0.5,
          vy: (Math.random() - 0.5) * 0.5,
          type: characterTypes[i % characterTypes.length],
          rotation: Math.random() * Math.PI * 2,
          rotationSpeed: (Math.random() - 0.5) * 0.02,
        });
      }
    };

    const drawCharacter = (character: Character, isDark: boolean) => {
      if (!ctx) return;

      ctx.save();
      ctx.translate(character.x, character.y);
      ctx.rotate(character.rotation);

      const size = 30;
      const opacity = isDark ? 0.15 : 0.12;
      const color = isDark ? `rgba(255, 255, 255, ${opacity})` : `rgba(0, 0, 0, ${opacity})`;

      ctx.strokeStyle = color;
      ctx.fillStyle = color;
      ctx.lineWidth = 2;
      ctx.lineCap = "round";
      ctx.lineJoin = "round";

      // Draw character based on type
      switch (character.type) {
        case "student":
          // Graduation cap
          ctx.beginPath();
          ctx.moveTo(-size/2, 0);
          ctx.lineTo(size/2, 0);
          ctx.lineTo(size/2, size/8);
          ctx.lineTo(-size/2, size/8);
          ctx.closePath();
          ctx.fill();
          ctx.beginPath();
          ctx.moveTo(0, -size/3);
          ctx.lineTo(-size/2.5, -size/6);
          ctx.lineTo(size/2.5, -size/6);
          ctx.closePath();
          ctx.fill();
          // Tassel
          ctx.beginPath();
          ctx.arc(size/2.5, -size/6, size/12, 0, Math.PI * 2);
          ctx.fill();
          break;

        case "employer":
          // Briefcase
          ctx.beginPath();
          ctx.rect(-size/2.5, -size/4, size/1.25, size/2);
          ctx.fill();
          ctx.beginPath();
          ctx.rect(-size/6, -size/2.5, size/3, size/4);
          ctx.fill();
          break;

        case "mentor":
          // Person with star
          ctx.beginPath();
          ctx.arc(0, -size/4, size/5, 0, Math.PI * 2);
          ctx.fill();
          ctx.beginPath();
          ctx.moveTo(-size/3, size/3);
          ctx.lineTo(0, 0);
          ctx.lineTo(size/3, size/3);
          ctx.stroke();
          // Star
          ctx.beginPath();
          for (let i = 0; i < 5; i++) {
            const angle = (i * 4 * Math.PI) / 5 - Math.PI / 2;
            const x = size/2.5 + Math.cos(angle) * size/8;
            const y = -size/3 + Math.sin(angle) * size/8;
            if (i === 0) ctx.moveTo(x, y);
            else ctx.lineTo(x, y);
          }
          ctx.closePath();
          ctx.fill();
          break;

        case "placement":
          // Building/organization
          ctx.beginPath();
          ctx.rect(-size/2.5, -size/3, size/1.25, size/1.5);
          ctx.stroke();
          // Windows
          for (let i = 0; i < 2; i++) {
            for (let j = 0; j < 3; j++) {
              ctx.beginPath();
              ctx.rect(-size/4 + i * size/3.5, -size/5 + j * size/6, size/8, size/10);
              ctx.fill();
            }
          }
          break;
      }

      ctx.restore();
    };

    const drawParticles = () => {
      if (!ctx || !canvas) return;

      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Get computed styles to use theme colors
      const isDark = document.documentElement.classList.contains("dark");
      const particleColor = isDark ? "rgba(255, 255, 255, 0.4)" : "rgba(0, 0, 0, 0.3)";
      const lineColor = isDark ? "rgba(255, 255, 255, 0.1)" : "rgba(0, 0, 0, 0.08)";

      // Update and draw particles
      particles.forEach((particle) => {
        particle.x += particle.vx;
        particle.y += particle.vy;

        // Bounce off edges
        if (particle.x < 0 || particle.x > canvas.width) particle.vx *= -1;
        if (particle.y < 0 || particle.y > canvas.height) particle.vy *= -1;

        // Draw particle
        ctx.beginPath();
        ctx.arc(particle.x, particle.y, 2, 0, Math.PI * 2);
        ctx.fillStyle = particleColor;
        ctx.fill();
      });

      // Draw connections
      const maxDistance = 150;
      for (let i = 0; i < particles.length; i++) {
        for (let j = i + 1; j < particles.length; j++) {
          const dx = particles[i].x - particles[j].x;
          const dy = particles[i].y - particles[j].y;
          const distance = Math.sqrt(dx * dx + dy * dy);

          if (distance < maxDistance) {
            const opacity = (1 - distance / maxDistance) * (isDark ? 0.15 : 0.1);
            ctx.beginPath();
            ctx.strokeStyle = lineColor.replace(/[\d.]+\)/, `${opacity})`);
            ctx.lineWidth = 1;
            ctx.moveTo(particles[i].x, particles[i].y);
            ctx.lineTo(particles[j].x, particles[j].y);
            ctx.stroke();
          }
        }
      }

      // Update and draw characters
      characters.forEach((character) => {
        character.x += character.vx;
        character.y += character.vy;
        character.rotation += character.rotationSpeed;

        // Bounce off edges with padding
        const padding = 50;
        if (character.x < padding || character.x > canvas.width - padding) character.vx *= -1;
        if (character.y < padding || character.y > canvas.height - padding) character.vy *= -1;

        drawCharacter(character, isDark);
      });

      animationFrameId = requestAnimationFrame(drawParticles);
    };

    resizeCanvas();
    createParticles();
    createCharacters();
    drawParticles();

    const handleResize = () => {
      resizeCanvas();
      createParticles();
      createCharacters();
    };

    window.addEventListener("resize", handleResize);

    return () => {
      window.removeEventListener("resize", handleResize);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 -z-10 pointer-events-none"
      aria-hidden="true"
    />
  );
}
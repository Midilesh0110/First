# OneCampus Java Backend (Skeleton)

This is a minimal Spring Boot skeleton placed under `src/java-backend/` to showcase the Java part of the stack. It exposes `/api/opportunities` with mocked data and ships with an in-memory H2 database and a starter SQL schema (`schema.sql`).

Quick start:

```bash
cd src/java-backend
./mvnw spring-boot:run # or: mvn spring-boot:run
```

Then visit: `http://localhost:8080/api/opportunities`

Note: The Next.js app also exposes a JS route at `/api/opportunities` with the same mocked data for local UI use.
-- Core SQL schema for OneCampus (students, employers, internships, applications)

CREATE TABLE IF NOT EXISTS students (
  id INTEGER PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(120) NOT NULL,
  email VARCHAR(160) UNIQUE NOT NULL,
  department VARCHAR(120)
);

CREATE TABLE IF NOT EXISTS employers (
  id INTEGER PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(160) NOT NULL,
  website VARCHAR(200)
);

CREATE TABLE IF NOT EXISTS internships (
  id INTEGER PRIMARY KEY AUTO_INCREMENT,
  title VARCHAR(160) NOT NULL,
  company_id INTEGER NOT NULL,
  location VARCHAR(160),
  type VARCHAR(60) CHECK (type IN ('Internship','Training')),
  FOREIGN KEY (company_id) REFERENCES employers(id)
);

CREATE TABLE IF NOT EXISTS applications (
  id INTEGER PRIMARY KEY AUTO_INCREMENT,
  student_id INTEGER NOT NULL,
  internship_id INTEGER NOT NULL,
  status VARCHAR(40) DEFAULT 'applied',
  applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (student_id) REFERENCES students(id),
  FOREIGN KEY (internship_id) REFERENCES internships(id)
);
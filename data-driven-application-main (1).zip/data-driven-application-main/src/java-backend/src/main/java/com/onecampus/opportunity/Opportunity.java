package com.onecampus.opportunity;

public record Opportunity(
        Long id,
        String title,
        String company,
        String location,
        String type
) {}
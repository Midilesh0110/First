package com.onecampus.opportunity;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/opportunities")
public class OpportunityController {

    @GetMapping
    public List<Opportunity> list() {
        return List.of(
                new Opportunity(1L, "Frontend Intern", "Acme Corp", "Remote", "Internship"),
                new Opportunity(2L, "Java Backend Intern", "Globex", "Bangalore", "Internship"),
                new Opportunity(3L, "Data Analyst Trainee", "Initech", "Pune", "Training")
        );
    }
}
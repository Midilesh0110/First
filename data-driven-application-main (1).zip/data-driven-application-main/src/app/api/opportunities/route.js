import { NextResponse } from "next/server";

export async function GET() {
  // Mocked data to represent what the Java backend would return
  const data = [
    { id: 1, title: "Frontend Intern", company: "Acme Corp", location: "Remote", type: "Internship" },
    { id: 2, title: "Java Backend Intern", company: "Globex", location: "Bangalore", type: "Internship" },
    { id: 3, title: "Data Analyst Trainee", company: "Initech", location: "Pune", type: "Training" },
  ];
  return NextResponse.json({ opportunities: data });
}
import type { Metadata } from "next";
import "./globals.css";
import VisualEditsMessenger from "../visual-edits/VisualEditsMessenger";
import ErrorReporter from "@/components/ErrorReporter";
import Script from "next/script";
import { GraduationCap } from "lucide-react";
import HeaderAuth from "@/components/auth/header-auth";

export const metadata: Metadata = {
  title: "MentorMesh",
  description: "One campus-centric portal for internships and training.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">
        <ErrorReporter />
        <Script
          src="https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/scripts//route-messenger.js"
          strategy="afterInteractive"
          data-target-origin="*"
          data-message-type="ROUTE_CHANGE"
          data-include-search-params="true"
          data-only-in-iframe="true"
          data-debug="true"
          data-custom-data='{"appName": "YourApp", "version": "1.0.0", "greeting": "hi"}'
        />
        {/* Site Header */}
        <header className="border-b bg-white/70 backdrop-blur supports-[backdrop-filter]:bg-white/50 dark:bg-background sticky top-0 z-40">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
            <a href="/" className="flex items-center gap-2 font-semibold">
              <span className="inline-flex h-8 w-8 items-center justify-center rounded-md bg-foreground/10">
                <GraduationCap className="h-5 w-5 text-foreground" />
              </span>
              <span>MentorMesh</span>
            </a>
            <nav className="hidden md:flex items-center gap-6 text-sm">
              <a href="/" className="hover:underline">Home</a>
              <a href="/marketplace" className="hover:underline">Marketplace</a>
              <a href="/dashboard/student" className="hover:underline">Student</a>
              <a href="/dashboard/employer" className="hover:underline">Employer</a>
              <a href="/dashboard/mentor" className="hover:underline">Mentor</a>
              <a href="/dashboard/placement" className="hover:underline">Placement Cell</a>
              <a href="/plain-html" className="hover:underline">HTML Demo</a>
            </nav>
            <div className="flex items-center gap-3 text-sm">
              {/* Always-visible Home link, including on mobile */}
              <a href="/" className="px-3 py-1.5 rounded-md border hover:bg-muted">Home</a>
              {/* Auth buttons (hidden when logged in) */}
              <HeaderAuth />
            </div>
          </div>
        </header>

        {children}

        {/* Site Footer */}
        <footer className="mt-20 border-t">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-10 grid gap-6 md:grid-cols-3">
            <div>
              <div className="font-semibold">MentorMesh</div>
              <p className="text-sm text-muted-foreground mt-2">Automating internships from application to placement across the entire campus ecosystem.</p>
            </div>
            <div>
              <div className="font-medium mb-2">Partners</div>
              <ul className="text-sm space-y-1 text-muted-foreground">
                <li>University Alliances</li>
                <li>Industry Mentors</li>
                <li>Employer Network</li>
              </ul>
            </div>
            <div>
              <div className="font-medium mb-2">Contact</div>
              <ul className="text-sm space-y-1 text-muted-foreground">
                <li>Email: partnerships@onecampus.example</li>
                <li>Support: support@onecampus.example</li>
              </ul>
            </div>
          </div>
          <div className="text-xs text-muted-foreground text-center pb-6">© {new Date().getFullYear()} MentorMesh. All rights reserved.</div>
        </footer>
        <VisualEditsMessenger />
      </body>
    </html>
  );
}
"use client"

import { useMemo, useState, useEffect } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import Link from "next/link";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

// Mock dataset for internships
const listings = [
  {
    id: "react-fe-remote",
    title: "Frontend Intern (React)",
    company: "Acme Labs",
    location: "Remote",
    type: "remote",
    role: "student",
    skills: ["React", "TypeScript", "Tailwind"],
    description: "Work with our web team to build UI components and pages.",
    image: "https://images.unsplash.com/photo-1542831371-29b0f74f9713?q=80&w=1200&auto=format&fit=crop",
  },
  {
    id: "data-analyst-onsite",
    title: "Data Analyst Intern",
    company: "Insightify",
    location: "Bengaluru",
    type: "onsite",
    role: "student",
    skills: ["SQL", "Python", "Pandas"],
    description: "Analyze datasets and build dashboards for stakeholders.",
    image: "https://images.unsplash.com/photo-1551281044-8d8d0d8a1f7b?q=80&w=1200&auto=format&fit=crop",
  },
  {
    id: "mentor-program-hybrid",
    title: "Mentor - Summer Cohort",
    company: "OneCampus",
    location: "Hybrid",
    type: "hybrid",
    role: "mentor",
    skills: ["Mentoring", "Assessment", "Communication"],
    description: "Guide a cohort of 10-15 students across project milestones.",
    image: "https://images.unsplash.com/photo-1513258496099-48168024aec0?q=80&w=1200&auto=format&fit=crop",
  },
  {
    id: "employer-collab-remote",
    title: "Employer Partnership Program",
    company: "OneCampus",
    location: "Remote",
    type: "remote",
    role: "employer",
    skills: ["Hiring", "Collaboration"],
    description: "Join our campus network to source interns efficiently.",
    image: "https://images.unsplash.com/photo-1521737604893-d14cc237f11d?q=80&w=1200&auto=format&fit=crop",
  },
];

export default function MarketplacePage() {
  const search = useSearchParams();
  const router = useRouter();
  const initialQ = search.get("q") || "";
  const initialRole = search.get("role") || "student";

  const [q, setQ] = useState(initialQ);
  const [role, setRole] = useState(initialRole);
  const [type, setType] = useState<string>("any");

  // JS API data (from /api/opportunities)
  const [apiOpps, setApiOpps] = useState<Array<{ id: number; title: string; company: string; location: string; type: string }>>([]);
  const [apiLoading, setApiLoading] = useState(true);
  const [apiError, setApiError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    async function load() {
      try {
        setApiLoading(true);
        const res = await fetch("/api/opportunities");
        if (!res.ok) throw new Error("Network error");
        const json = await res.json();
        if (!cancelled) setApiOpps(json.opportunities || []);
      } catch (e) {
        if (!cancelled) setApiError("Failed to load opportunities");
      } finally {
        if (!cancelled) setApiLoading(false);
      }
    }
    load();
    return () => {
      cancelled = true;
    };
  }, []);

  const filtered = useMemo(() => {
    return listings.filter((l) => {
      const qMatch = q
        ? [l.title, l.company, l.description, ...l.skills].join(" ").toLowerCase().includes(q.toLowerCase())
        : true;
      const roleMatch = role ? l.role === role : true;
      const typeMatch = type === "any" ? true : l.type === type;
      return qMatch && roleMatch && typeMatch;
    });
  }, [q, role, type]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const params = new URLSearchParams();
    if (q) params.set("q", q);
    if (role) params.set("role", role);
    router.push(`/marketplace?${params.toString()}`);
  };

  return (
    <main className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-10">
      <h1 className="text-2xl md:text-3xl font-semibold">Internship Marketplace</h1>
      <p className="text-muted-foreground mt-1">Search, filter, and apply to opportunities. Applications are protected by login.</p>

      <form onSubmit={handleSearch} className="mt-6 grid gap-3 md:grid-cols-[1fr_180px_180px_120px]">
        <div>
          <Label htmlFor="q">Search</Label>
          <Input id="q" placeholder="e.g., React, Data Analyst" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
        <div>
          <Label>Role</Label>
          <Select value={role} onValueChange={setRole}>
            <SelectTrigger>
              <SelectValue placeholder="Select role" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="student">Student</SelectItem>
              <SelectItem value="employer">Employer</SelectItem>
              <SelectItem value="mentor">Mentor</SelectItem>
              <SelectItem value="placement">Placement Cell</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label>Type</Label>
          <Select value={type} onValueChange={setType}>
            <SelectTrigger>
              <SelectValue placeholder="Any" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="any">Any</SelectItem>
              <SelectItem value="remote">Remote</SelectItem>
              <SelectItem value="onsite">Onsite</SelectItem>
              <SelectItem value="hybrid">Hybrid</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="flex items-end">
          <Button type="submit" className="w-full">Search</Button>
        </div>
      </form>

      <div className="mt-8 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {filtered.map((item) => (
          <Card key={item.id} className="overflow-hidden">
            <div className="h-36 w-full overflow-hidden">
              <img src={item.image} alt={item.title} className="h-full w-full object-cover" />
            </div>
            <CardHeader>
              <CardTitle className="text-lg">{item.title}</CardTitle>
              <CardDescription>{item.company} • {item.location}</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-3">{item.description}</p>
              <div className="flex flex-wrap gap-1.5 mb-4">
                {item.skills.map((s) => (
                  <Badge key={`${item.id}-${s}`} variant="secondary">{s}</Badge>
                ))}
              </div>
              <Link href={{ pathname: "/marketplace/apply", query: { id: item.id } }}>
                <Button className="w-full">Apply</Button>
              </Link>
            </CardContent>
          </Card>
        ))}
        {filtered.length === 0 && (
          <div className="col-span-full text-sm text-muted-foreground">No results. Try adjusting filters.</div>
        )}
      </div>

      {/* JS API-backed opportunities */}
      <div className="mt-12">
        <h2 className="text-xl font-semibold">Live opportunities (JS API)</h2>
        {apiLoading && <div className="text-sm text-muted-foreground mt-2">Loading...</div>}
        {apiError && <div className="text-sm text-destructive mt-2">{apiError}</div>}
        {!apiLoading && !apiError && (
          <div className="mt-4 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {apiOpps.map((o) => (
              <Card key={o.id}>
                <CardHeader>
                  <CardTitle className="text-base">{o.title}</CardTitle>
                  <CardDescription>{o.company} • {o.location}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-xs text-muted-foreground">Type: {o.type}</div>
                  <Link href="/marketplace/apply">
                    <Button size="sm" className="mt-3 w-full">Apply</Button>
                  </Link>
                </CardContent>
              </Card>
            ))}
            {apiOpps.length === 0 && (
              <div className="col-span-full text-sm text-muted-foreground">No live opportunities found.</div>
            )}
          </div>
        )}
      </div>
    </main>
  );
}
"use client"

import { useSearchParams, useRouter } from "next/navigation";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { useSession } from "@/lib/auth-client";

export default function ApplyPage() {
  const search = useSearchParams();
  const router = useRouter();
  const { data: session, isPending } = useSession();
  const [submitted, setSubmitted] = useState(false);

  const listingId = search.get("id");

  if (isPending) return <div className="p-8">Loading...</div>;

  if (!listingId) {
    return (
      <main className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-10">
        <Card>
          <CardHeader>
            <CardTitle>Invalid application</CardTitle>
            <CardDescription>Missing listing identifier.</CardDescription>
          </CardHeader>
          <CardContent>
            <Button variant="outline" onClick={() => router.push("/marketplace")}>Back to Marketplace</Button>
          </CardContent>
        </Card>
      </main>
    );
  }

  const handleApply = async () => {
    // In a real app, call POST /api/applications with bearer token
    setSubmitted(true);
    setTimeout(() => router.push("/dashboard/student"), 1000);
  };

  return (
    <main className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-10">
      <Card>
        <CardHeader>
          <CardTitle>Apply to listing</CardTitle>
          <CardDescription>
            Listing ID: {listingId} • Signed in as {session?.user?.email}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {submitted ? (
            <div className="text-sm">Application submitted! Redirecting to your dashboard…</div>
          ) : (
            <div className="flex gap-3">
              <Button onClick={handleApply}>Confirm Application</Button>
              <Button variant="outline" onClick={() => router.back()}>Cancel</Button>
            </div>
          )}
        </CardContent>
      </Card>
    </main>
  );
}
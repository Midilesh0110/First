"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { useSession } from "@/lib/auth-client";
import RoleGuard from "@/components/RoleGuard";
import { SuggestedInternships } from "@/components/suggested-internships";

export default function PlacementDashboard() {
  const { data: session, isPending } = useSession();

  if (isPending) return <div className="p-8">Loading...</div>;

  return (
    <>
      <RoleGuard allowed="placement" />
      <main className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-10">
        <h1 className="text-2xl md:text-3xl font-semibold">Placement Cell Dashboard</h1>
        <p className="text-muted-foreground mt-1">
          Welcome{session?.user?.name ? `, ${session.user.name}` : ""}. Oversee campus-wide internships and placements.
        </p>

        <div className="mt-8 grid gap-6 md:grid-cols-3">
          <Card>
            <CardHeader>
              <CardTitle>Campus Overview</CardTitle>
              <CardDescription>Applications, offers, and conversions.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-sm text-muted-foreground">Dashboard metrics coming soon.</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle>Manage Employers</CardTitle>
              <CardDescription>Approve postings and monitor activity.</CardDescription>
            </CardHeader>
            <CardContent>
              <Button disabled>Open Employer Panel (soon)</Button>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle>Compliance & Docs</CardTitle>
              <CardDescription>Offer letters, NDAs, and reports.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-sm text-muted-foreground">Templates and workflows coming soon.</div>
            </CardContent>
          </Card>
        </div>

        <div className="mt-6">
          <Link href="/marketplace"><Button variant="outline">View Marketplace</Button></Link>
        </div>

        <SuggestedInternships roleType="placement" />
      </main>
    </>
  );
}
"use client"

import Link from "next/link";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useSession } from "@/lib/auth-client";
import RoleGuard from "@/components/RoleGuard";
import { PathAdvisor } from "@/components/student/PathAdvisor";
import { SuggestedInternships } from "@/components/suggested-internships";

export default function StudentDashboard() {
  const { data: session, isPending } = useSession();

  if (isPending) return <div className="p-8">Loading...</div>;

  return (
    <>
      <RoleGuard allowed="student" />
      <main className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-10">
        <h1 className="text-2xl md:text-3xl font-semibold">Student Dashboard</h1>
        <p className="text-muted-foreground mt-1">Welcome{session?.user?.name ? `, ${session.user.name}` : ""}. Track your applications and discover opportunities.</p>

        <div className="mt-8 grid gap-6 md:grid-cols-3">
          <Card>
            <CardHeader>
              <CardTitle>Find Internships</CardTitle>
              <CardDescription>Browse and apply to curated roles.</CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/marketplace"><Button>Open Marketplace</Button></Link>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle>Your Applications</CardTitle>
              <CardDescription>View status and next steps.</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">No applications yet.</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle>Progress Tracker</CardTitle>
              <CardDescription>Milestones and mentor feedback.</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">Coming soon.</p>
            </CardContent>
          </Card>
        </div>

        <div className="mt-8">
          <PathAdvisor />
        </div>

        <SuggestedInternships roleType="student" />
      </main>
    </>
  );
}
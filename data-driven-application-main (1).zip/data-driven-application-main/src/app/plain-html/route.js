import { NextResponse } from "next/server";

export async function GET() {
  const html = `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>OneCampus — Pure HTML Demo</title>
  <style>
    :root { --bg: #ffffff; --fg: #1a1a1a; --muted: #6b7280; --primary: #111827; --ring: #d1d5db; }
    * { box-sizing: border-box; }
    body { margin: 0; font-family: ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Arial, Noto Sans, sans-serif; color: var(--fg); background: var(--bg); }
    header { position: sticky; top: 0; backdrop-filter: saturate(180%) blur(10px); border-bottom: 1px solid var(--ring); background: rgba(255,255,255,0.7); }
    .container { max-width: 72rem; margin: 0 auto; padding: 0 1rem; }
    .nav { height: 64px; display: flex; align-items: center; justify-content: space-between; }
    .brand { display: inline-flex; align-items: center; gap: .5rem; font-weight: 600; text-decoration: none; color: inherit; }
    .chip { display: inline-flex; align-items: center; border: 1px solid var(--ring); padding: 0.25rem 0.5rem; border-radius: 9999px; font-size: 12px; color: var(--muted); }
    .hero { text-align: center; padding: 4rem 1rem 3rem; }
    h1 { font-size: clamp(1.875rem, 1.2rem + 2vw, 3rem); margin: 1rem 0 0.5rem; }
    p.lead { max-width: 42rem; margin: 0.75rem auto 0; color: var(--muted); }
    .cta { display: inline-flex; gap: .75rem; margin-top: 1rem; }
    .btn { display: inline-flex; align-items: center; justify-content: center; padding: .75rem 1rem; border: 1px solid var(--ring); border-radius: .5rem; background: #111827; color: white; text-decoration: none; font-weight: 500; }
    .btn.secondary { background: white; color: #111827; }
    .grid { display: grid; gap: 1rem; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); margin: 1.5rem auto; max-width: 80rem; padding: 0 1rem; }
    .card { border: 1px solid var(--ring); border-radius: .5rem; overflow: hidden; background: white; }
    .card img { width: 100%; height: 112px; object-fit: cover; display: block; }
    .card .content { padding: .75rem; }
    .card .title { font-size: 14px; font-weight: 600; }
    .card .desc { font-size: 12px; color: var(--muted); }
    footer { border-top: 1px solid var(--ring); margin-top: 3rem; padding: 1.5rem 1rem; color: var(--muted); font-size: 12px; text-align: center; }
  </style>
</head>
<body>
  <header>
    <div class="container nav">
      <a class="brand" href="/">🎓 OneCampus</a>
      <nav style="display:flex; gap: 1rem; font-size: 14px;">
        <a href="/">Home</a>
        <a href="/marketplace">Marketplace</a>
        <a href="/plain-html">HTML Demo</a>
      </nav>
    </div>
  </header>

  <main>
    <section class="hero">
      <span class="chip">OneCampus</span>
      <h1>One portal for internships and training</h1>
      <p class="lead">A single digital platform where students, placement cells, mentors, and employers come together. Automate the internship journey from application to placement.</p>
      <div class="cta">
        <a class="btn" href="/marketplace">Explore Opportunities</a>
        <a class="btn secondary" href="/sign-in">Sign In</a>
      </div>
    </section>

    <section class="container">
      <h2 style="font-size: 1.125rem; font-weight: 600;">Get started by role</h2>
      <p style="font-size: 14px; color: var(--muted);">Choose your workspace</p>
    </section>

    <section class="grid">
      <div class="card">
        <img src="https://images.unsplash.com/photo-1559136555-9303baea8ebd?q=80&w=1200&auto=format&fit=crop" alt="Students" />
        <div class="content">
          <div class="title">Students</div>
          <div class="desc">Discover and track internships</div>
        </div>
      </div>
      <div class="card">
        <img src="https://images.unsplash.com/photo-1521737604893-d14cc237f11d?q=80&w=1200&auto=format&fit=crop" alt="Employers" />
        <div class="content">
          <div class="title">Employers</div>
          <div class="desc">Post and manage roles</div>
        </div>
      </div>
      <div class="card">
        <img src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?q=80&w=1200&auto=format&fit=crop" alt="Mentors" />
        <div class="content">
          <div class="title">Mentors</div>
          <div class="desc">Guide and evaluate</div>
        </div>
      </div>
      <div class="card">
        <img src="https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?q=80&w=1200&auto=format&fit=crop" alt="Placement Cell" />
        <div class="content">
          <div class="title">Placement Cell</div>
          <div class="desc">Oversee campus-wide</div>
        </div>
      </div>
    </section>
  </main>

  <footer>
    © OneCampus. Pure HTML + CSS demo.
  </footer>
</body>
</html>`;

  return new NextResponse(html, { headers: { "Content-Type": "text/html; charset=utf-8" } });
}
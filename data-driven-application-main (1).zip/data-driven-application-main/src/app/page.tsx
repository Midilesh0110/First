import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Layers, Bot, Sparkles, Briefcase, TrendingUp, Code, Megaphone, BarChart, Palette, FileText, Building2 } from "lucide-react";
import SignInCTA from "@/components/auth/sign-in-cta";
import { AnimatedBackground } from "@/components/ui/animated-background";

export default function Home() {
  return (
    <main className="relative">
      <AnimatedBackground />
      {/* Hero */}
      <section className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8 py-16 md:py-24 text-center">
        <span className="inline-flex items-center rounded-full border px-3 py-1 text-xs text-muted-foreground">
          MentorMesh
        </span>
        <h1 className="mt-4 text-3xl md:text-5xl font-semibold tracking-tight">
          One portal for internships and training
        </h1>
        <p className="mt-4 text-muted-foreground max-w-2xl mx-auto">
          A single digital platform where students, placement cells, mentors, and employers come together.
          Automate the internship journey from application to placement.
        </p>
        <div className="mt-6 flex flex-col sm:flex-row gap-3 justify-center">
          <Link href="/marketplace">
            <Button size="lg">Explore Opportunities</Button>
          </Link>
          <SignInCTA />
        </div>
      </section>

      {/* Key Benefits */}
      <section className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8 py-6">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          <Benefit
            icon={<Layers className="h-5 w-5 text-primary" />}
            title="Unified Workflow"
            desc="All stakeholders collaborate in one place—no scattered tools."
          />
          <Benefit
            icon={<Bot className="h-5 w-5 text-primary" />}
            title="Automation"
            desc="Streamline every step from application to placement."
          />
          <Benefit
            icon={<Sparkles className="h-5 w-5 text-primary" />}
            title="Smart Matching"
            desc="Connect students with best‑fit opportunities."
          />
        </div>
      </section>

      {/* Categories */}
      <section className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8 py-6">
        <h2 className="text-xl font-semibold mb-4">Browse by Category</h2>
        <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide">
          <CategoryChip icon={<Code className="h-4 w-4" />} label="Technology" />
          <CategoryChip icon={<Megaphone className="h-4 w-4" />} label="Marketing" />
          <CategoryChip icon={<BarChart className="h-4 w-4" />} label="Business" />
          <CategoryChip icon={<Palette className="h-4 w-4" />} label="Design" />
          <CategoryChip icon={<FileText className="h-4 w-4" />} label="Content" />
          <CategoryChip icon={<Building2 className="h-4 w-4" />} label="Operations" />
        </div>
      </section>

      {/* Hot Opportunities */}
      <section className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-xl font-semibold flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-primary" />
              Hot Opportunities
            </h2>
            <p className="text-sm text-muted-foreground">Featured internships closing soon</p>
          </div>
          <Link href="/marketplace">
            <Button variant="outline" size="sm">View All</Button>
          </Link>
        </div>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          <OpportunityCard
            title="Software Development Intern"
            company="Tech Innovations Ltd"
            location="Remote"
            type="Full-time"
            duration="3 months"
          />
          <OpportunityCard
            title="Marketing Associate"
            company="Digital Growth Agency"
            location="Hybrid"
            type="Part-time"
            duration="6 months"
          />
          <OpportunityCard
            title="UI/UX Design Intern"
            company="Creative Studios"
            location="On-site"
            type="Full-time"
            duration="4 months"
          />
        </div>
      </section>

      {/* Trending Programs */}
      <section className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8 py-6">
        <h2 className="text-xl font-semibold mb-4">Trending Training Programs</h2>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <ProgramCard
            title="Full Stack Development"
            provider="CodeAcademy Pro"
            image="https://images.unsplash.com/photo-1498050108023-c5249f4df085?q=80&w=1200&auto=format&fit=crop"
          />
          <ProgramCard
            title="Digital Marketing"
            provider="Marketing Institute"
            image="https://images.unsplash.com/photo-1460925895917-afdab827c52f?q=80&w=1200&auto=format&fit=crop"
          />
          <ProgramCard
            title="Data Science"
            provider="Analytics Hub"
            image="https://images.unsplash.com/photo-1551288049-bebda4e38f71?q=80&w=1200&auto=format&fit=crop"
          />
          <ProgramCard
            title="UI/UX Design"
            provider="Design School"
            image="https://images.unsplash.com/photo-1561070791-2526d30994b5?q=80&w=1200&auto=format&fit=crop"
          />
        </div>
      </section>
    </main>
  );
}

function Benefit({ icon, title, desc }: { icon: React.ReactNode; title: string; desc: string }) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-start gap-3">
        <span className="rounded-md bg-primary/10 p-2">{icon}</span>
        <div>
          <CardTitle className="text-base">{title}</CardTitle>
          <CardDescription className="text-sm">{desc}</CardDescription>
        </div>
      </CardHeader>
    </Card>
  );
}

function CategoryChip({ icon, label }: { icon: React.ReactNode; label: string }) {
  return (
    <Link href={`/marketplace?category=${label.toLowerCase()}`}>
      <Button variant="outline" className="flex items-center gap-2 whitespace-nowrap">
        {icon}
        {label}
      </Button>
    </Link>
  );
}

function OpportunityCard({ 
  title, 
  company, 
  location, 
  type, 
  duration 
}: { 
  title: string; 
  company: string; 
  location: string; 
  type: string; 
  duration: string;
}) {
  return (
    <Card className="group transition-all hover:shadow-md">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <CardTitle className="text-base line-clamp-1">{title}</CardTitle>
            <CardDescription className="text-sm mt-1">{company}</CardDescription>
          </div>
          <span className="inline-flex items-center rounded-full bg-primary/10 px-2 py-1 text-xs font-medium text-primary">
            {type}
          </span>
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col gap-1 text-xs text-muted-foreground mb-3">
          <div className="flex items-center gap-1">
            <Briefcase className="h-3 w-3" />
            <span>{location} • {duration}</span>
          </div>
        </div>
        <Link href="/marketplace">
          <Button size="sm" className="w-full">View Details</Button>
        </Link>
      </CardContent>
    </Card>
  );
}

function ProgramCard({ 
  title, 
  provider, 
  image 
}: { 
  title: string; 
  provider: string; 
  image: string;
}) {
  return (
    <Card className="overflow-hidden group transition-all hover:shadow-md">
      <div className="h-32 w-full overflow-hidden">
        <img
          src={image}
          alt={title}
          className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
        />
      </div>
      <CardHeader className="pb-2">
        <CardTitle className="text-sm line-clamp-1">{title}</CardTitle>
        <CardDescription className="text-xs">{provider}</CardDescription>
      </CardHeader>
      <CardContent>
        <Link href="/marketplace">
          <Button size="sm" variant="outline" className="w-full">Enroll Now</Button>
        </Link>
      </CardContent>
    </Card>
  );
}